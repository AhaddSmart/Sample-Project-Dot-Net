﻿global using Domain.Common;
//global using BlankProject_NETCORE6.Domain.Entities;
global using Domain.Enums;
//global using BlankProject_NETCORE6.Domain.Events;
global using Domain.Exceptions;