﻿namespace Domain.Enums
{
    public enum ECountry
    {
        Pakistan = 1
    }
    public enum ECurrency
    {
        PKR = 1,
        SAR = 2,
        USD = 3,
        EUR = 4
    }
}
