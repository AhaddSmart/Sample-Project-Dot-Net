﻿namespace Infrastructure.Models;

public class PermissionModel
{
    public string role { get; set; }
    public string[] Permission { get; set; }

}
