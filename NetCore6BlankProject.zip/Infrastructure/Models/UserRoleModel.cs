﻿namespace Infrastructure.Models;

public class UserRoleModel
{
    public string name { get; set; }
    public string id { get; set; }
}
