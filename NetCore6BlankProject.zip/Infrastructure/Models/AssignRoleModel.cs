﻿namespace Infrastructure.Models;

public class AssignRoleModel
{
    public string UserID { get; set; }
    public string Role { get; set; }
}
